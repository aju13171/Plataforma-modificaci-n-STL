﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using IxMilia.Stl;
using UnityEditor;
using System.IO;
using System.Threading;
using vectorSTL;

public class FileLoader : MonoBehaviour
{

    //used variables
    private GameObject master;
    StlFile stlLoaded;
    List<VectorTriangle> vTriangleList;
    Thread myThread;

    //export process variables
    StlFile ObjectExport;
    int thread_run;

    // Start is called before the first frame update
    void Start()
    {
        thread_run = 0;
        master = GameObject.Find("Master");
    }

    // Update is called once per frame
    void Update()
    {
        //check if thread already finish
        if(thread_run == 2)
        {
            thread_run = 0;
            string path2 = EditorUtility.SaveFilePanel("Guardar modelo en formato STL", "", "myObject.stl","STL");
            ExportStlFile(path2);
        }
    }

    public void loadModel()
    {
        try
        {
            stlLoaded = openFile();
            vTriangleList = convertTriangles(stlLoaded.Triangles);
            int index = master.GetComponent<RenderScript>().addWorldObject(vTriangleList);
        }
        catch (System.Exception)
        {
            EditorUtility.DisplayDialog("ERROR", "Error al cargar el archivo: No se seleccionó un archivo o no existe", "OK");
        }
    }

    private StlFile openFile()
    {
        StlFile file;
        string path = "N/A";
        //get path
        path = EditorUtility.OpenFilePanel("Abrir modelo en formato STL", "", "STL");
        using (FileStream fs = new FileStream(path, FileMode.Open))
        {
            file = StlFile.Load(fs);
        }
        return file;
    }

    private void ExportStlFile(string path)
    {
        using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
        {
            ObjectExport.Save(fs);
        }
    }

    public void ProcessMeshToStl(Vector3[] vertices, int[] triangles, Vector3[] normals, string name)
    {
        ObjectExport = new StlFile();
        ObjectExport.SolidName = name;
        myThread = new Thread(() => ProcessToIxmilia(vertices,triangles,normals));
        thread_run = 1;
        myThread.Start();
    }

    private void ProcessToIxmilia(Vector3[] vertices, int[] triangles, Vector3[] normals)
    {
        for(int i=0; i<triangles.Length; i+=3)
        {
            ObjectExport.Triangles.Add(new StlTriangle(
                new StlNormal(normals[triangles[i]].x, normals[triangles[i]].y, normals[triangles[i]].z),
                new StlVertex(vertices[triangles[i]].x, vertices[triangles[i]].y, vertices[triangles[i]].z),
                new StlVertex(vertices[triangles[i+1]].x, vertices[triangles[i + 1]].y, vertices[triangles[i + 1]].z),
                new StlVertex(vertices[triangles[i + 2]].x, vertices[triangles[i + 2]].y, vertices[triangles[i + 2]].z)
                ));
        }
        thread_run = 2;
    }

    private List<VectorTriangle> convertTriangles(List<StlTriangle> list)
    {
        List<VectorTriangle> newList = new List<VectorTriangle>();

        Thread thread1 = new Thread(() => converter(0, list.Count, list, ref newList));
        thread1.Start();

        bool iFlag = true;
        while (iFlag)
        {
            if (thread1.ThreadState == ThreadState.Stopped)
            {
                iFlag = false;
            }
        }

        return newList;
    }

    private void converter(int start, int end, List<StlTriangle> list, ref List<VectorTriangle> newList)
    {
        StlTriangle j;
        //se verifica si fue llamado por thread 1 o 2
        for (int i = start; i < end; i++)
        {
            j = list[i];
            //agrego el nuevo triangulo
            newList.Add(new VectorTriangle(new Vector3(j.Vertex1.X, j.Vertex1.Y, j.Vertex1.Z),
                                            new Vector3(j.Vertex2.X, j.Vertex2.Y, j.Vertex2.Z),
                                            new Vector3(j.Vertex3.X, j.Vertex3.Y, j.Vertex3.Z),
                                            new Vector3(j.Normal.X, j.Normal.Y, j.Normal.Z)));
        }
    }
}
