﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cutter2 : MonoBehaviour
{
    GameObject master;

    private void Start()
    {
        master = GameObject.Find("Master");
    }


    public void AnalizePoints()
    {
        //debug or help
        int positive = 0;
        int negative = 0;
        int sliced = 0;

        Vector3 n;
        float side1,side2,side3;

        List<Mesh> buff = new List<Mesh>();
        buff = master.GetComponent<RenderScript>().GetActiveInfo(); //buff[0] = obj mesh | buff[1] = plane mesh
        Vector3[] Pvertices = buff[0].vertices;
        int[] Otriangles = buff[1].triangles;
        Vector3[] Overtices = buff[1].vertices;
        Vector3[] Onormals = buff[1].normals;

        List<int> PositiveT = new List<int>();
        List<int> NegativeT = new List<int>();
        List<Vector3> PositiveV = new List<Vector3>();
        List<Vector3> NegativeV = new List<Vector3>();
        List<Vector3> PositiveN = new List<Vector3>();
        List<Vector3> NegativeN = new List<Vector3>();

        //calculate normal vector of plane
        n = Vector3.Cross((Pvertices[1] - Pvertices[0]), (Pvertices[2] - Pvertices[0]));

        //identify side
        for(int i = 0; i<Otriangles.Length; i+=3)
        {
            //por triangulo
            side1 = Vector3.Dot((Overtices[Otriangles[i]] - Pvertices[0]), n);
            side2 = Vector3.Dot((Overtices[Otriangles[i+1]] - Pvertices[0]), n);
            side3 = Vector3.Dot((Overtices[Otriangles[i+2]] - Pvertices[0]), n);
            string sides = side1 + ";" + side2 + ";" + side3;
            if((side1 >= 0) && (side2 >= 0) && (side3 >= 0))
            {
                positive++;
                //add to new list
                PositiveV.Add(Overtices[i]);
                //PositiveT.Add();
            }
            else if((side1<=0) && (side2<=0) && (side3 <= 0))
            {
                negative++;
                //print("L negative: " + sides);
            }
            else
            {
                sliced++;
                //print("sliced: " + sides);
            }
        }
        
        /*
        print("Triangulos: " + Otriangles.Length);
        print(" Vertices: " + Overtices.Length);
        print("L positives: " + positive);
        print("L negative: " + negative);
        print("sliced: " + sliced);
        */

    }

    public int GetPlaneSide(Vector3 A, Vector3 B, Vector3 C, Vector3 P)
    {
        //calculate normal vector
        Vector3 n = Vector3.Cross((B - A), (C - A));
        float side = Vector3.Dot((P - A), n);
        if(side > 0)
        {
            print("positive side");
            return 1;
        }
        else
        {
            print("negative side");
            return -1;
        }
    }
}
