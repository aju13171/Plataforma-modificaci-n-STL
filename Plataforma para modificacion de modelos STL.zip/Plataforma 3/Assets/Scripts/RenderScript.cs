﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vectorSTL;
using System.Threading;

public class RenderScript : MonoBehaviour
{
    Mesh activeMesh;
    int activeID;

    Thread myThread;

    List<ModelInfo> objetos; //contiene todos los objetos del espacio
    GameObject cutPlane, phantomPlane;
    [SerializeField]
    GameObject joinPlanes;
    [SerializeField]
    GameObject objectPanel;
    Mesh planeMesh, phantomMesh;
    Material mat1, mat2, mat3;

    int sendInfo;
    int workingIndex;
    List<Vector3> workingVertices;
    List<int> workingTriangles;
    List<Vector3> workingNormals;

    public GameObject loader;

    // Start is called before the first frame update
    void Start()
    {
        joinPlanes = GameObject.Find("CuttingPlanes");
        objectPanel = GameObject.Find("Object list");
        loader = GameObject.Find("Abrir archivo");
        sendInfo = 0;
        //creo la lista
        objetos = new List<ModelInfo>();

        //obtengo los materiales
        mat1 = Resources.Load<Material>("Material/Model material");
        mat2 = Resources.Load<Material>("Material/Idle material");
        mat3 = Resources.Load<Material>("Material/Plane material");

        //creo el objeto para el plano
        cutPlane = new GameObject();
        cutPlane.layer = 10;
        cutPlane.name = "cutPlane";
        cutPlane.AddComponent<MeshFilter>();
        cutPlane.AddComponent<MeshRenderer>();
        cutPlane.GetComponent<MeshRenderer>().material = mat3;
        planeMesh = cutPlane.GetComponent<MeshFilter>().mesh;
        //info del plano
        planeMesh.vertices = new List<Vector3>()
        {
            new Vector3(200,0,-200), //1
            new Vector3(200,0,200), //2
            new Vector3(-200,0,200), //3
            new Vector3(-200,0,-200) //4
        }.ToArray();

        planeMesh.triangles = new List<int>()
        {
            0, 2, 3, 0, 1, 2
        }.ToArray();

        //phantom plane
        phantomPlane = new GameObject();
        phantomPlane.layer = 10;
        phantomPlane.name = "PhantomPlane";
        phantomPlane.AddComponent<MeshFilter>();
        phantomPlane.AddComponent<MeshRenderer>();
        phantomPlane.GetComponent<MeshRenderer>().material = mat3;
        phantomMesh = phantomPlane.GetComponent<MeshFilter>().mesh;
        //info del plano reflejado
        phantomMesh.vertices = new List<Vector3>()
        {
            new Vector3(200,0,-200), //1
            new Vector3(200,0,200), //2
            new Vector3(-200,0,200), //3
            new Vector3(-200,0,-200) //4
        }.ToArray();

        phantomMesh.triangles = new List<int>()
        {
            0, 3, 2, 0, 2, 1
        }.ToArray();

        //creo el objeto que contiene ambos planos
        cutPlane.transform.SetParent(joinPlanes.transform, false);
        phantomPlane.transform.SetParent(joinPlanes.transform, false);
        joinPlanes.gameObject.SetActive(false);
        //test de creacion de objetos
        //CreateObject();

        //test get vertices
        /*
        Vector3[] a = planeMesh.vertices;
        
        for (int i = 0; i < a.Length; i++)
        {
            print(a[i]);
        }
        */
    }

    // Update is called once per frame
    void Update()
    {
        if(sendInfo == 1)
        {
            sendInfo = 2;
            renderObject(workingIndex, workingVertices, workingTriangles, workingNormals);
        }
    }

    public void PlanePos()
    {
        List<Vector3> store = new List<Vector3>();
        Vector3[] test = cutPlane.GetComponent<MeshFilter>().mesh.vertices;
        for(int i=0; i<test.Length; i++)
        {
            store.Add(cutPlane.transform.TransformPoint(test[i]));

        }
        print("\n");
        for (int i =0; i < store.Count; i++)
        {
            print(store[i]);
        }
    }

    public void Planeinfo()
    {
        Mesh temp = cutPlane.GetComponent<MeshFilter>().mesh;
        print("\n----- * ----");
        for(int i=0; i<temp.vertices.Length; i++)
        {
            print(temp.vertices[i]);
        }
    }

    public void ChangeMaterial(int id)
    {
        for(int i=0; i<objetos.Count; i++)
        {
            if(i != id)
            {
                objetos[i].meshRenderer.material = mat2;
            }
            else
            {
                objetos[id].meshRenderer.material = mat1;
                activeMesh = objetos[id].Model;
                activeID = objetos[id].Index;
            }
        }
    }

    //not used
    public List<Mesh> GetActiveInfo()
    {
        List<Mesh> buff = new List<Mesh>();
        buff.Add(planeMesh);
        buff.Add(activeMesh);
        return buff;
    }

    public ModelInfo GetActiveObject()
    {
        return objetos[activeID];
    }

    public Vector3[] GetPlaneVertices()
    {
        Vector3[] VertexList = new Vector3[4];
        Vector3[] PlaneList = planeMesh.vertices;
        for(int i=0; i < planeMesh.vertexCount; i++)
        {
            VertexList[i] = cutPlane.transform.TransformPoint(PlaneList[i]);
        }
        return VertexList;
    }

    //not used
    public int GetACtiveID()
    {
        return activeID;
    }

    private void renderObject(int index,List<Vector3> vertices, List<int> triangles, List<Vector3> normals)
    {
        objetos[index].Model.Clear();
        objetos[index].Model.vertices = vertices.ToArray();
        objetos[index].Model.triangles = triangles.ToArray();
        objetos[index].Model.normals = normals.ToArray();
        sendInfo = 0;
    }

    public void SubstituteObject(int id, Mesh newMesh)
    {
        //it's assumed that the active element hasn't changed
        //if id is not available, it is an aditional element
        if (id == -1)
        {
            int newIndex = CreateObject();
            //process information
            objetos[newIndex].Model.Clear();
            objetos[newIndex].Model.vertices = newMesh.vertices;
            objetos[newIndex].Model.normals = newMesh.normals;
            objetos[newIndex].Model.triangles = newMesh.triangles;
            /*debug
            objetos[newIndex].Model.vertices = objetos[activeID].Model.vertices;
            objetos[newIndex].Model.normals = objetos[activeID].Model.normals;
            objetos[newIndex].Model.triangles = objetos[activeID].Model.triangles;
            */
        }
        else
        {
            objetos[id].Model.Clear();
            objetos[id].Model.vertices = newMesh.vertices;
            objetos[id].Model.normals = newMesh.normals;
            objetos[id].Model.triangles = newMesh.triangles;
        }
    }

    private int CreateObject()
    {
        int objectIndex = objetos.Count;
        //print("debug>objectIndex: " + objectIndex);
        GameObject dummy = new GameObject();
        dummy.name = "item " + (objetos.Count).ToString();
        dummy.AddComponent<ClickAction>();
        dummy.GetComponent<ClickAction>().CreateMe(objectIndex);
        dummy.layer = 9;
        dummy.AddComponent<MeshFilter>();
        dummy.GetComponent<MeshFilter>().mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        dummy.AddComponent<MeshRenderer>();
        dummy.GetComponent<MeshRenderer>().material = mat2;
        objetos.Add(new ModelInfo(dummy.GetComponent<MeshFilter>().mesh, dummy.GetComponent<MeshRenderer>(),objectIndex));
        objectPanel.GetComponent<ObjectManager>().AddObject(objectIndex);
        return objectIndex;
    }

    public void CreateStlObject()
    {
        loader.GetComponent<FileLoader>().ProcessMeshToStl(objetos[activeID].Model.vertices, objetos[activeID].Model.triangles, objetos[activeID].Model.normals, "objeto" + activeID);
    }

    public int addWorldObject(List<VectorTriangle> triangles)
    {
        //reinicio las listas
        workingVertices = new List<Vector3>();
        workingTriangles = new List<int>();
        workingNormals = new List<Vector3>();
        //obtengo el indice del nuevo objeto
        workingIndex = CreateObject();
        //proceso la información
        sendInfo = 0;
        myThread = new Thread(() => processList(triangles));
        myThread.Start();
        return workingIndex;
    }

    public void processList(List<VectorTriangle> info)
    {
        int delay = 0;
        VectorTriangle temp;
        Vector3 v, n, eq;
        int j;
        float mag;
        bool f = false;
        float e = 0.1f;
        int used = 0;

        for (int i = 0; i < info.Count; i++)
        {
            if (delay > 800)
            {
                delay = 0;
                //print("analizados: " + used);
                sendInfo = 1;
            }
            if (sendInfo != 0)
            {
                i = i - 1;
            }

            else
            {
                used++;
                delay = delay + 1;
                //check if vertex order is correct
                temp = info[i];
                v = Vector3.Normalize(Vector3.Cross((temp.Vertex2 - temp.Vertex1), (temp.Vertex3 - temp.Vertex2)));
                n = Vector3.Normalize(temp.Normals);
                eq = v - n;
                mag = eq.sqrMagnitude;
                if (mag < e)
                {
                    f = true;
                    workingVertices.Add(temp.Vertex1);
                    workingVertices.Add(temp.Vertex2);
                    workingVertices.Add(temp.Vertex3);
                    //normales
                    workingNormals.Add(temp.Normals);
                    workingNormals.Add(temp.Normals);
                    workingNormals.Add(temp.Normals);
                    j = workingVertices.Count;
                    //triangulos index
                    workingTriangles.Add(j - 3);
                    workingTriangles.Add(j - 2);
                    workingTriangles.Add(j - 1);
                }
                if (!f)
                {
                    workingVertices.Add(temp.Vertex1);
                    workingVertices.Add(temp.Vertex3);
                    workingVertices.Add(temp.Vertex2);
                    //normales
                    workingNormals.Add(temp.Normals);
                    workingNormals.Add(temp.Normals);
                    workingNormals.Add(temp.Normals);
                    j = workingVertices.Count;
                    //triangulos indes
                    workingTriangles.Add(j - 3);
                    workingTriangles.Add(j - 2);
                    workingTriangles.Add(j - 1);
                }
                f = false;
            }
        }
		sendInfo = 1;
    }

}
