﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;

public class ObjectManager : MonoBehaviour
{
    GameObject ObjectPanel;

    //prefabs
    public GameObject togglePrefab;
    Vector3 position;
    int xpos;
    List<int> index = new List<int>();
    List<GameObject> toggles;

    private void Start()
    {
        xpos = 230;
        position = new Vector3(0, 0, 0);
        ObjectPanel = GameObject.Find("Object list");
        toggles = new List<GameObject>();
    }

    public void AddObject(int i)
    {
        index.Add(i);
        toggles.Add(CreateToggle(i));
    }

    public GameObject CreateToggle(int id)
    {
        GameObject newToggle;
        newToggle = Instantiate(togglePrefab,ObjectPanel.transform,false);
        newToggle.name = "toggle" + id;
        newToggle.GetComponentInChildren<Text>().text = "item" + id;
        newToggle.GetComponent<ClickAction>().CreateMe(id);
        newToggle.transform.localPosition = new Vector3(0, xpos);
        xpos -= 80;
        newToggle.GetComponent<Toggle>().isOn = false;
        return newToggle;
    }

    public void ChangeState(int id)
    {
        for(int i=0; i<toggles.Count; i++)
        {
            if (i != id)
            {
                toggles[i].GetComponent<Toggle>().isOn = false;
            }
        }
    }
}
