﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using vectorSTL;

public class Cutter : MonoBehaviour
{
    GameObject master;

    //Separate mesh variables
    ModelInfo Object;
    Vector3[] PlaneV;
    Vector3 n, Pa, Pb;
    int Pside;

    //variables to control new 2 mesh lists
    int IndexP = 0;
    int IndexN = 0;
    int Tstate = -2;
    List<Vector3> PosV, PosN;
    List<Vector3> NegV, NegN;
    List<int> PosT, NegT;
    Mesh buff;
    int sliced;

    //old vertices, normals and triangles
    Vector3[] OVertices;
    Vector3[] ONormals;
    int[] OTriangles;

    void Start()
    {
        master = GameObject.Find("Master");
        //debug test
        /*
        Vector3 n_t = new Vector3(16, 16, 16);
        Vector3 P1_t = new Vector3(-0.7f, 0.2f, 1);
        Vector3 P3_t = new Vector3(2.9f, 0.4f, 2.9f);
        Vector3 Pa_t = new Vector3(4, 0, 0);
        print(IntersectionPoint(P1_t, P3_t, Pa_t, n_t));
        */
    }

    public void SeparateMesh()
    {
        //reset variables to control new 2 mesh lists
        IndexP = 0;
        IndexN = 0;
        PosV = new List<Vector3>();
        PosN = new List<Vector3>();
        PosT = new List<int>();
        NegV = new List<Vector3>();
        NegN = new List<Vector3>();
        NegT = new List<int>();
        sliced = 0;

        //retrieving information from master
        Object = master.GetComponent<RenderScript>().GetActiveObject();
        PlaneV = master.GetComponent<RenderScript>().GetPlaneVertices();
        n = Vector3.Cross((PlaneV[1] - PlaneV[0]), (PlaneV[2] - PlaneV[0]));
        //A = PlaneV[0]
        //storing old info in arrays
        OVertices = Object.Model.vertices;
        ONormals = Object.Model.normals;
        OTriangles = Object.Model.triangles;
        //debug
        print("Overtices: " + OVertices.Length);
        print("Otriangles: " + OTriangles.Length);
        print("ONormals: " + ONormals.Length);
        //debug
        bool debug_run = false;

        //for(int i = 0; i < OTriangles.Length; i += 3)
        for (int i = 0; i < OTriangles.Length; i += 3)
        {
            
            Tstate = GetPlaneSide(OVertices[OTriangles[i]], OVertices[OTriangles[i + 1]], OVertices[OTriangles[i + 2]], n, PlaneV[0]);
            //add to the correct list
            if (debug_run)
            {
                //v1
                PosT.Add(IndexP);
                PosV.Add(OVertices[OTriangles[i]]);
                PosN.Add(ONormals[OTriangles[i]]);
                //v2
                PosT.Add(IndexP + 1);
                PosV.Add(OVertices[OTriangles[i + 1]]);
                PosN.Add(ONormals[OTriangles[i + 1]]);
                //v3
                PosT.Add(IndexP + 2);
                PosV.Add(OVertices[OTriangles[i + 2]]);
                PosN.Add(ONormals[OTriangles[i + 2]]);
                //move positive index of new lists
                IndexP += 3;
            }
            else if(Tstate == 1)
            {
                AddSlice(OVertices[OTriangles[i]], OVertices[OTriangles[i + 1]], OVertices[OTriangles[i + 2]], ONormals[OTriangles[i]], 1);
            }
            else if(Tstate == -1)
            {
                AddSlice(OVertices[OTriangles[i]], OVertices[OTriangles[i + 1]], OVertices[OTriangles[i + 2]], ONormals[OTriangles[i]], -1);
            }
            else
            {
                sliced+=3;
                if(Tstate == -2)
                {
                    //find the two points knowing that point OVertices[OTriangles[i]] is the oddone
                    Pa = IntersectionPoint(OVertices[OTriangles[i]], OVertices[OTriangles[i+1]], PlaneV[0], n);
                    Pb = IntersectionPoint(OVertices[OTriangles[i]], OVertices[OTriangles[i+2]], PlaneV[0], n);

                    //check if point is on positive or negative side
                    Pside = GetPointSide(OVertices[OTriangles[i]], n, PlaneV[0]);
                    if (Pside > 0)
                    {
                        //add to negative list the easy triangle
                        CheckDirection(OVertices[OTriangles[i]], Pa, Pb, ONormals[OTriangles[i]], 1);
                        //triangulation for the negative side
                        CheckDirection(OVertices[OTriangles[i + 1]], OVertices[OTriangles[i + 2]], Pa, ONormals[OTriangles[i]], -1);
                        CheckDirection(OVertices[OTriangles[i + 2]], Pa, Pb, ONormals[OTriangles[i]], -1);
                    }
                    else
                    {
                        CheckDirection(OVertices[OTriangles[i]], Pa, Pb, ONormals[OTriangles[i]], -1);
                        //triangulation
                        CheckDirection(OVertices[OTriangles[i + 1]], OVertices[OTriangles[i + 2]], Pa, ONormals[OTriangles[i]], 1);
                        CheckDirection(OVertices[OTriangles[i + 2]], Pa, Pb, ONormals[OTriangles[i]], 1);
                    }
                }
                else if(Tstate == -3)
                {
                    //find the two points knowing that point Overtices[Otriangles[i+1]] is the oddone
                    Pa = IntersectionPoint(OVertices[OTriangles[i + 1]], OVertices[OTriangles[i]], PlaneV[0], n);
                    Pb = IntersectionPoint(OVertices[OTriangles[i + 1]], OVertices[OTriangles[i+2]], PlaneV[0], n);
                    Pside = GetPointSide(OVertices[OTriangles[i+1]], n, PlaneV[0]);
                    if (Pside > 0)
                    {
                        CheckDirection(OVertices[OTriangles[i + 1]], Pa, Pb, ONormals[OTriangles[i + 1]], 1);
                        //triangulaiton
                        CheckDirection(OVertices[OTriangles[i]], OVertices[OTriangles[i + 2]], Pa, ONormals[OTriangles[i]], -1);
                        CheckDirection(OVertices[OTriangles[i + 2]], Pa, Pb, ONormals[OTriangles[i]], -1);
                        
                    }
                    else
                    {
                        CheckDirection(OVertices[OTriangles[i + 1]], Pa, Pb, ONormals[OTriangles[i + 1]], -1);
                        //triangulation
                        CheckDirection(OVertices[OTriangles[i]], OVertices[OTriangles[i + 2]], Pa, ONormals[OTriangles[i]], 1);
                        CheckDirection(OVertices[OTriangles[i + 2]], Pa, Pb, ONormals[OTriangles[i]], 1);
                    }
                }
                else
                {
                    //find the two points knowing that point Overtices[Otriangles[i+2]] is the oddone
                    Pa = IntersectionPoint(OVertices[OTriangles[i + 2]], OVertices[OTriangles[i]], PlaneV[0], n);
                    Pb = IntersectionPoint(OVertices[OTriangles[i + 2]], OVertices[OTriangles[i+1]], PlaneV[0], n);
                    Pside = GetPointSide(OVertices[OTriangles[i + 2]], n, PlaneV[0]);
                    if (Pside > 0)
                    {
                        CheckDirection(OVertices[OTriangles[i + 2]], Pa, Pb, ONormals[OTriangles[i + 2]], 1);
                        //triangulation
                        CheckDirection(OVertices[OTriangles[i]], OVertices[OTriangles[i + 1]], Pa, ONormals[OTriangles[i]], -1);
                        CheckDirection(OVertices[OTriangles[i + 1]], Pa, Pb, ONormals[OTriangles[i]], -1);
                    }
                    else
                    {
                        CheckDirection(OVertices[OTriangles[i + 2]], Pa, Pb, ONormals[OTriangles[i + 2]], -1);
                        CheckDirection(OVertices[OTriangles[i]], OVertices[OTriangles[i + 1]], Pa, ONormals[OTriangles[i]], 1);
                        CheckDirection(OVertices[OTriangles[i + 1]], Pa, Pb, ONormals[OTriangles[i]], 1);
                    }
                }
                
            }
        }

        //sending Positive mesh
        buff = new Mesh();
        buff.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        buff.Clear();
        buff.vertices = PosV.ToArray();
        buff.normals = PosN.ToArray();
        buff.triangles = PosT.ToArray();
        master.GetComponent<RenderScript>().SubstituteObject(Object.Index, buff); //Object.Index

        //sending Negative mesh
        buff = new Mesh();
        buff.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        buff.Clear();
        buff.vertices = NegV.ToArray();
        buff.normals = NegN.ToArray();
        buff.triangles = NegT.ToArray();
        master.GetComponent<RenderScript>().SubstituteObject(-1, buff);

        //debug
        print("Sliced finished");
        print("VPositives: " + PosV.Count);
        print("nPositives: " + PosN.Count);
        print("TPositives: " + PosT.Count);
        print("Negatives: " + NegV.Count);
        print("Sliced: " + sliced);
    }

    private void CheckDirection(Vector3 P1, Vector3 P2, Vector3 P3, Vector3 N, int Side)
    {
        float e = 0.1f;
        Vector3 n_normalize = Vector3.Normalize(N);
        Vector3 v_normalize = Vector3.Normalize(Vector3.Cross((P2 - P1), (P3 - P2)));
        float mag = (v_normalize - n_normalize).sqrMagnitude;
        if (mag < e)
        {
            //correct order
            AddSlice(P1, P2, P3, N, Side);
        }
        else
        {
            //inverted order
            AddSlice(P1, P3, P2, N, Side);
        }
    }

    private void AddSlice(Vector3 P1, Vector3 P2, Vector3 P3, Vector3 N, int Side)
    {
        if (Side > 0)
        {
            //add vertices
            //V1
            PosT.Add(IndexP);
            PosV.Add(P1);
            PosN.Add(N);
            //V2
            PosT.Add(IndexP + 1);
            PosV.Add(P2);
            PosN.Add(N);
            //V3
            PosT.Add(IndexP + 2);
            PosV.Add(P3);
            PosN.Add(N);
            //move indexP
            IndexP += 3;
        }
        else
        {
            //add vertices
            //V1
            NegT.Add(IndexN);
            NegV.Add(P1);
            NegN.Add(N);
            //V2
            NegT.Add(IndexN + 1);
            NegV.Add(P2);
            NegN.Add(N);
            //V3
            NegT.Add(IndexN + 2);
            NegV.Add(P3);
            NegN.Add(N);
            //move indexP
            IndexN += 3;
        }
    }

    private int GetPointSide(Vector3 P, Vector3 n, Vector3 A)
    {
        float side = Vector3.Dot((P - A), n);
        if (side < 0)
        {
            return -1;
        }
        else
        {
            return 1;
        }
    }

    private int GetPlaneSide(Vector3 P1, Vector3 P2, Vector3 P3, Vector3 n, Vector3 A)
    {
        float side1 = Vector3.Dot((P1 - A), n);
        float side2 = Vector3.Dot((P2 - A), n);
        float side3 = Vector3.Dot((P3 - A), n);
		//check if one of them is = 0
		/* x y z
		if (x == 0 && (y >0) == (z<0)){
			pa = get intersection point between y,z
			if y>0 {add to postive side && add z to negative} 
			else{add negative side && z to positive}
		*/
		
        //check if triangle in the positive side, negative or is sliced
        if((side1 >=0) && (side2 >=0) && (side3 >= 0))
        {
            //is positive
            return 1;
        }
        else if((side1 <=0) && (side2 <= 0) && (side3 <= 0))
        {
            //is negative
            return -1;
        }
        else
        {
            if((side1>=0) == (side2>=0))
            {
                return -4; //side3 is different
            }
            else if((side1>=0) == (side3 >= 0))
            {
                return -3; //side2 is different
            }
            else
            {
                return -2; //side1 is different
            }
        }
    }

    private Vector3 IntersectionPoint(Vector3 P1,Vector3 P3,Vector3 Pa,Vector3 n)
    {
        Vector3 Pinter;

        //Calculate Lab
        Vector3 Lab = P3 - P1;
        float div = Vector3.Dot((P3 - Pa), n) / (Vector3.Dot(Lab, n));
        Pinter = P3 - (Lab*div);
        return Pinter;
    }
}
