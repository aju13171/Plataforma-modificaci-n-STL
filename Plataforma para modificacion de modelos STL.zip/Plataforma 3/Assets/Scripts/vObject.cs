﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace vectorSTL
{
    public class VectorTriangle
    {
        public Vector3 Vertex1 { get; set; }
        public Vector3 Vertex2 { get; set; }
        public Vector3 Vertex3 { get; set; }
        public Vector3 Normals { get; set; }

        public VectorTriangle(Vector3 v1, Vector3 v2, Vector3 v3, Vector3 normal)
        {
            Vertex1 = v1;
            Vertex2 = v2;
            Vertex3 = v3;
            Normals = normal;
        }

        public string GetInfo()
        {
            string a;
            a = "v->\tV1: " + Vertex1.ToString("f6") +
                "\n\tV2: " + Vertex2.ToString("f6") +
                "\n\tV3: " + Vertex3.ToString("f6") +
                "\n\tN: " + Normals.ToString("f6");
            return a;
        }
    }

    public class ModelInfo
    {
        public Mesh Model { get; set; } //to modify mesh
        public MeshRenderer meshRenderer { get; set; } //to modify material
        public int Index { get; set; } //index in the objects list located at Master<RenderScript>

        public ModelInfo(Mesh info, MeshRenderer info2, int index)
        {
            Model = info;
            meshRenderer = info2;
            Index = index;
        }
    }
}
