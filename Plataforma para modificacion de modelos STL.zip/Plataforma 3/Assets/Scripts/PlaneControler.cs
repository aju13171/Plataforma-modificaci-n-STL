﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneControler : MonoBehaviour
{
    public GameObject cuttingPlane;
    public GameObject planeButton;

    bool move_plane = false; //identify if plane is moved or rotated

    public void SetPlaneInfo(GameObject plane)
    {
        cuttingPlane = plane;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.UpArrow))
        {
            if (move_plane)
            {

            }
            //print("up");

        }
        if (Input.GetKey(KeyCode.DownArrow))
        {
            //print("down");
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            //print("left");
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            //print("right");
        }
    }

    public void showPlane()
    {
        cuttingPlane.gameObject.SetActive(!cuttingPlane.activeSelf);
        planeButton.gameObject.SetActive(!planeButton.activeSelf);
    }
    public void toggleControl()
    {
        move_plane = !move_plane;
    }
}
