﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ClickAction : MonoBehaviour
{
    //[SerializeField]
    private int index;
    public GameObject toggleState;
    public GameObject objectList;
    public GameObject master;

    private void Start()
    {
        objectList = GameObject.Find("Object list");
        master = GameObject.Find("Master");
    }

    public void CreateMe(int i)
    {
        index = i;
    }

    public void ImClicked()
    {
        //print("clicked" + index.ToString());
        //print("state: " + toggleState.GetComponent<Toggle>().isOn);
        if (toggleState.GetComponent<Toggle>().isOn)
        {
            print("Im active: " + index);
            master.GetComponent<RenderScript>().ChangeMaterial(index);
            objectList.GetComponent<ObjectManager>().ChangeState(index);
        }
    }
}
