﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour
{
    public GameObject camera;

    // Start is called before the first frame update
    bool move_zoom = false; //to zoom
    bool move_camera = false; //to rotate camera

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            print("c");

        }
        if (Input.GetKeyDown(KeyCode.Z))
        {
            print("zoom");
        }
    }
}
